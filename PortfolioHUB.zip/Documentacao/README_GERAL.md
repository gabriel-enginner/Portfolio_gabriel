# PortfolioHUB

Repositório com projetos acadêmicos e pessoais criado para o desafio de versionamento do Bootcamp I - CEUB.

Inclui projetos em Python com foco em boas práticas de versionamento e documentação.
