# Calculadora Simples

Este é um projeto de calculadora básica em Python.

## Funcionalidades
- Soma
- Subtração
- Multiplicação
- Divisão (com tratamento de erro para divisão por zero)

## Como executar
Execute o arquivo `calculadora_simples.py` com Python 3.

```bash
python calculadora_simples.py
```

## Autor
Gabriel - CEUB
